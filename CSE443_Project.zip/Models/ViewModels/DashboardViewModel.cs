﻿namespace CSE443_Project.Models.ViewModels
{
    public class DashboardViewModel
    {
        public int TotalUsers { get; set; }
        public int TotalJobs { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}
