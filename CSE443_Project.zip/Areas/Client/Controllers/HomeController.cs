﻿using Microsoft.AspNetCore.Mvc;

namespace CSE443_Project.Areas.Client.Controllers
{
    [Area("Client")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
