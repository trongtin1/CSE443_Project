using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CSE443_Project.Areas.Admin.Views.Admin
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
