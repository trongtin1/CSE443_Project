using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CSE443_Project.Areas.Admin.Views.Users
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
