using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CSE443_Project.Areas.Admin.Views.Users
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
