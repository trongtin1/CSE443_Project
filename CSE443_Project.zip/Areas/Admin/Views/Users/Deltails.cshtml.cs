using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CSE443_Project.Areas.Admin.Views.Users
{
    public class DeltailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
